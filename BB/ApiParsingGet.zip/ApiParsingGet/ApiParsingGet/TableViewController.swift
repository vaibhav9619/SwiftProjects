//
//  TableViewController.swift
//  ApiParsingGet
//
//  Created by Vaibhav-VVDN on 10/03/19.
//  Copyright © 2019 VVDN. All rights reserved.
//

import UIKit

class TableViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
