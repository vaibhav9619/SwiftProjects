//
//  PeripheralViewController.swift
//  BLEPoc
//
//  Created by Vaibhav-VVDN on 25/04/19.
//  Copyright © 2019 VVDN. All rights reserved.
//

import UIKit
import CoreBluetooth

class PeripheralViewController: UIViewController,CBPeripheralManagerDelegate,UITextViewDelegate,CBPeripheralDelegate,CBCentralManagerDelegate {
    var peripheralNew:CBPeripheral!
    var centralManager = CBCentralManager()
    var peripheralManager = CBPeripheralManager()
    var sendDataIndex:Int!
    var dataToSend:Data!
     var data:Data!
    
    @IBOutlet weak var peripheralLabel: UILabel!
    @IBOutlet weak var NameOfDevice: UILabel!
    @IBOutlet weak var centralLabel: UILabel!
    @IBOutlet weak var status: UILabel!
    var transferCharacteristic:CBMutableCharacteristic!
    @IBOutlet weak var peripheralTextView: UITextView!
    @IBOutlet weak var startSharing: UISwitch!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.peripheralManager.delegate = self
             data = Data.init()
        self.centralManager.delegate = self
    
     
    
    }
    override func viewDidAppear(_ animated: Bool) {
        
        self.peripheralManager.startAdvertising([CBAdvertisementDataServiceUUIDsKey:[BLEService_UUID]])
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.peripheralManager.stopAdvertising()
        super.viewWillDisappear(animated)
    }
    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        if(peripheral.state != .poweredOn)
        {
            let messageController =  UIAlertController(title: "Bluetooth is Off", message: "Turn On!!!", preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                self.navigationController?.popViewController(animated: true)
            } )
            messageController.addAction(action)
            
            self.present(messageController, animated: true, completion: nil)
        }
        self.transferCharacteristic = CBMutableCharacteristic(type: BLE_Characteristic_uuid_Tx, properties: CBCharacteristicProperties.notify, value: nil, permissions: CBAttributePermissions.readable)
        
        let transferService:CBMutableService = CBMutableService(type: BLEService_UUID, primary: true)
        transferService.characteristics = [self.transferCharacteristic]
        self.peripheralManager.add(transferService)
    }
    
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
        self.dataToSend = peripheralTextView.text.data(using: String.Encoding.utf8)

        // Reset the index
        sendDataIndex = 0;

        // Start sending
        self.sendData()
    }
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
        print("un")
    }
    fileprivate var sendingEOM = false
    fileprivate func sendData()
    {
        if sendingEOM {
            // send it
            let didSend = peripheralManager.updateValue(
                "EOM".data(using: String.Encoding.utf8)!,
                for: transferCharacteristic!,
                onSubscribedCentrals: nil
            )

          
            if (didSend == true) {

                // It did, so mark it as sent
                sendingEOM = false

                print("Sent: EOM")
            }

       
            return
        }
        guard sendDataIndex < dataToSend.count else {
            // No data left.  Do nothing
            return
        }

      

        var didSend = true

        while didSend {
            // Make the next chunk

            // Work out how big it should be
            let amountToSend = dataToSend!.count - sendDataIndex!;


            // Copy out the data we want
            let chunk = dataToSend!.withUnsafeBytes{(body: UnsafePointer<UInt8>) in
                return Data(
                    bytes: body + sendDataIndex!,
                    count: amountToSend
                )
            }

            // Send it
            didSend = peripheralManager.updateValue(
                chunk as Data,
                for: transferCharacteristic!,
                onSubscribedCentrals: nil
            )

            // If it didn't work, drop out and wait for the callback
            if (!didSend) {
                return
            }

            let stringFromData = NSString(
                data: chunk as Data,
                encoding: String.Encoding.utf8.rawValue
            )

            print("Sent: \(String(describing: stringFromData))")

            // It did send, so update our index
            sendDataIndex! += amountToSend;

            // Was it the last one?
            if (sendDataIndex! >= dataToSend!.count) {

                // It was - send an EOM

                // Set this so if the send fails, we'll send it next time
                sendingEOM = true

                // Send it
                let eomSent = peripheralManager.updateValue(
                    "EOM".data(using: String.Encoding.utf8)!,
                    for: transferCharacteristic!,
                    onSubscribedCentrals: nil
                )

                if (eomSent) {
                    // It sent, we're all done
                    sendingEOM = false
                    print("Sent: EOM")
                }

                return
            }
        }
    }

        func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) {
            // Start sending again
            sendData()
        }
    
    
    //central
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if #available(iOS 10.0, *) {
            if(self.centralManager.state != CBManagerState.poweredOn)
            {
                let messageController =  UIAlertController(title: "Bluetooth is Off", message: "Turn on!!", preferredStyle: .alert)
                let action = UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                    self.navigationController?.popViewController(animated: true)
                })
                messageController.addAction(action)
                
                self.present(messageController, animated: true, completion: nil)
                
                
                
            }
        } else {
            // Fallback on earlier versions
        }
        self.scan()
    }

    func scan()
    {
        self.centralManager.scanForPeripherals(withServices: [BLEService_UUID], options: nil)
        print("Scanning Started")
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        if(RSSI.intValue > -15)
        {
            return
        }
        if(RSSI.intValue < -35)
        {
            return
        }
        print("Discovered \(String(describing: peripheral.name)) \(RSSI)")
        if(self.peripheralNew != peripheral)
        {
            self.peripheralNew = peripheral
            print("Connecting To peripheral \(peripheral)")
            self.centralManager.connect(peripheral, options: nil)
        }
    }
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("Peripheral Connected")
        
        // Stop scanning
        self.centralManager.stopScan()
        print("Scanning stopped")
        
        
        
        // Clear the data that we may already have
        data.count = 0
        
        // Make sure we get the discovery callbacks
        peripheral.delegate = self
        
        // Search only for services that match our UUID
        peripheral.discoverServices([BLEService_UUID])
        let messageController =  UIAlertController(title: "Connected", message: peripheral.name, preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .default, handler: nil)
        messageController.addAction(action)
        
        self.present(messageController, animated: true, completion: nil)
        self.NameOfDevice.text = peripheral.name
       self.status.text = "Connected"
        self.centralLabel.text = peripheral.name
        self.peripheralLabel.text = "Peripheral Advertising"
        
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        let messageController =  UIAlertController(title: "Disconnected ", message: "Keep your device closer", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .default, handler: nil)

        messageController.addAction(action)
        
        self.present(messageController, animated: true, completion: nil)
        self.status.text = "Disconnected"
        self.NameOfDevice.text = ""
        self.peripheralNew = nil;
        self.centralLabel.text = "Not Connected to Any Peripheral"
        self.peripheralLabel.text = "Advertising Off"
        
        self.scan()
    }
    
    
    
    
//    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
//        if(peripheral.state != .poweredOn)
//        {
//         return
//        }
//
//            self.transferCharacteristic = CBMutableCharacteristic(type: BLE_Characteristic_uuid_Tx,
//                                                               properties: CBCharacteristicProperties.notify, value: nil,
//                                                               permissions: CBAttributePermissions.readable)
//            let serialService = CBMutableService(type: BLEService_UUID, primary: true)
//            serialService.characteristics = [self.transferCharacteristic]
//            self.peripheralManager.add(serialService)
//
//
//    }
//
//    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
//
//        for request in requests {
//            if let value = request.value {
//
//                //here is the message text that we receive, use it as you wish.
//                let messageText = String(data: value, encoding: String.Encoding.utf8) as! String
//                self.peripheralTextView.text = messageText
//            }
//            self.peripheralManager.respond(to: request, withResult: .success)
//        }
//    }
//
//
//
//
//
//    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
//        print("Central SUbsribed")
//        self.dataToSend = self.peripheralTextView.text.data(using: String.Encoding.utf8)
//        self.sendDataIndex = 0
//        self.sendData()
//
//    }
//
//    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
//        if let error = error {
//            print("\(error)")
//            return
//        }
//    }
//
//
//    func sendData()  {
//        var sendingEOM:Bool = false
//        let eom = "EOM".data(using: .ascii)
//
//        if(sendingEOM)
//        {
//            let didSend: Bool = self.peripheralManager.updateValue(eom!, for: self.transferCharacteristic, onSubscribedCentrals: nil)
//
//            if(didSend)
//            {
//                sendingEOM = false
//                print("SEnt")
//            }
//            return
//        }
//        if(self.sendDataIndex >= self.dataToSend.count)
//        {
//         return
//        }
//        var didSend:Bool = true
//        while(didSend)
//        {
//            var amountTOSend:Int = self.dataToSend.count - self.sendDataIndex
//            if(amountTOSend > 20)
//            {
//                amountTOSend = 20
//            }
//     //************************dount************************
//        //missing line
////            NSData *chunk = [NSData dataWithBytes:self.dataToSend.bytes+self.sendDataIndex length:amountToSend]; //Doubt
////
////            // Send i
////            didSend = [self.peripheralManager updateValue:chunk forCharacteristic:self.transferCharacteristic onSubscribedCentrals:nil];
////            let data = self.dataToSend as NSData
//
//
//            //datatosend to int
//            var num = 0
//            let data = self.dataToSend as NSData
//            data.getBytes(&num, length: MemoryLayout<Int>.size)
//
//            // already in int
//            let data1 = self.sendDataIndex
////            let raw1 = NSData(bytes: &data1, length: MemoryLayout.size(ofValue: data1))
//            // sum
//            let sum  = num + data1!
//            //int to data
//            let convert  = withUnsafeBytes(of: sum) {Data($0)}
//            let nsdata = convert as NSData
//            // data to unsafe pointer
//            let rawptr = nsdata.bytes
//            let chunk : Data = NSData(bytes: rawptr, length: amountTOSend) as Data
//            didSend = self.peripheralManager.updateValue(chunk, for: self.transferCharacteristic, onSubscribedCentrals: nil)
//
//      //*********************doubt*******************
//
//            if(!didSend)
//            {
//             return
//            }
//            let stringFromData : String = String(data: chunk, encoding: String.Encoding.utf8)!
//            print("sent \(stringFromData)")
//            self.sendDataIndex += amountTOSend
//            if(self.sendDataIndex >= self.dataToSend.count)
//            {
//                sendingEOM = true
//                let eomSent:Bool = self.peripheralManager.updateValue(eom!, for: self.transferCharacteristic, onSubscribedCentrals: nil)
//                if(eomSent)
//                {
//                    sendingEOM = false
//                    print("Sent EOM")
//                }
//                return
//            }
//
//        }
//    }
//    func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) {
//        self.sendData()
//    }
//
//    func textViewDidChange(_ textView: UITextView) {
//        if(self.startSharing.isOn)
//
//        {
//            self.startSharing.setOn(false, animated: true)
//            self.peripheralManager.stopAdvertising()
//        }
//    }
//    func textViewDidBeginEditing(_ textView: UITextView) {
//        let rightButton : UIBarButtonItem = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(dismissKeyboard))
//        self.navigationItem.rightBarButtonItem = rightButton
//    }
//    @objc func dismissKeyboard() {
//        self.peripheralTextView.resignFirstResponder()
//        self.navigationItem.rightBarButtonItem = nil
//    }


}
