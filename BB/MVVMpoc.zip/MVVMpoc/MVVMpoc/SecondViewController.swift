//
//  SecondViewController.swift
//  MVVMpoc
//
//  Created by Vaibhav-VVDN on 18/04/19.
//  Copyright © 2019 VVDN. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var CName: UILabel!
    @IBOutlet weak var CModel: UILabel!
    @IBOutlet weak var CAge: UILabel!
    @IBOutlet weak var CColor: UILabel!
    @IBOutlet weak var CCompany: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
//        let model1  =  NewModel(CarName: "Creta", CarModel: "2015 December", CarAge: "4 year old", CarColor: "White", CarCompany: "Hyundai")
//        let viewmodel1 = FirstViewModel(obj: model1)
//        self.CName.text = viewmodel1.CName
//        self.CModel.text = viewmodel1.CModel
//        self.CAge.text = viewmodel1.CAge
//        self.CColor.text = viewmodel1.CColor
//        self.CCompany.text = viewmodel1.CCompany
//        // Do any additional setup after loading the view.
    }
    



}
