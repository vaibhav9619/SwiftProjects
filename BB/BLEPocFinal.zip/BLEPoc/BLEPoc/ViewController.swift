//
//  ViewController.swift
//  BLEPoc
//
//  Created by Vaibhav-VVDN on 25/04/19.
//  Copyright © 2019 VVDN. All rights reserved.
//

import UIKit
import CoreBluetooth
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }


}
//extension ViewController : CBCentralManagerDelegate
//{
//    func centralManagerDidUpdateState(_ central: CBCentralManager) {
//        switch central.state {
//        case .unknown:
//            print("central.state is unknown")
//        case .resetting:
//            print("central.state is resetting")
//        case .unsupported:
//            print("central.state is unsupported")
//        case .unauthorized:
//            print("central.state is unauthorized")
//        case .poweredOff:
//            print("central.state is poweredOff")
//        case .poweredOn:
//            print("central.state is poweredOn")
//
//        default:
//            <#code#>
//        }
//    }
//
//
//}

