//
//  CentralViewController.swift
//  BLEPoc
//
//  Created by Vaibhav-VVDN on 25/04/19.
//  Copyright © 2019 VVDN. All rights reserved.
//

import UIKit
import CoreBluetooth
class CentralViewController: UIViewController,CBPeripheralDelegate,CBCentralManagerDelegate
{
//(Property = Write without response)
    

    @IBOutlet weak var centralTextView: UITextView!
    var centralManager = CBCentralManager()
    var peripheralNew: CBPeripheral!
    
    var data:Data!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        centralManager.delegate = self
        
        data = Data.init()
        
        
}
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if #available(iOS 10.0, *) {
            if(centralManager.state != CBManagerState.poweredOn)
            {
                return
            }
        } else {
            // Fallback on earlier versions
        }
        self.scan()
    }
    func scan()
    {
        self.centralManager.scanForPeripherals(withServices: [BLEService_UUID], options: nil)
        print("Scanning Started")
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        if(RSSI.intValue > -15)
        {
            return
        }
        if(RSSI.intValue < -35)
        {
            return
        }
        print("Discovered \(String(describing: peripheral.name)) \(RSSI)")
        if(self.peripheralNew != peripheral)
        {
            self.peripheralNew = peripheral
            print("Connecting To peripheral \(peripheral)")
            self.centralManager.connect(peripheral, options: nil)
        }
    }
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("Peripheral Connected")
        
        // Stop scanning
        centralManager.stopScan()
        print("Scanning stopped")
        

        
        // Clear the data that we may already have
        data.count = 0
        
        // Make sure we get the discovery callbacks
        peripheral.delegate = self
        
        // Search only for services that match our UUID
        peripheral.discoverServices([BLEService_UUID])
         let messageController =  UIAlertController(title: "Connected", message: peripheral.name, preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .default, handler: nil)
        messageController.addAction(action)
        
        self.present(messageController, animated: true, completion: nil)
        
        
    }
    
    
    
    
    
    
    
    
    
    

//
//
//
//
//
//
//
//
//    //**************************************************
//
//
//    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
//        print("Failed To connect Peripheral \(peripheral) \([error?.localizedDescription])")
//        self.clean()
//    }
//
//    func clean() {
//
//        let service1 = self.peripheralNew.services
//        if(self.peripheralNew.services != nil)
//        {
//            for service:CBService? in service1!
//            {
//                if(service?.characteristics != nil)
//                {
//                    for characterstic: CBCharacteristic? in (service?.characteristics)!
//                    {
//                        if((characterstic?.uuid.isEqual([BLE_Characteristic_uuid_Tx]))!)
//                        {
//                            self.peripheralNew.setNotifyValue(false, for: characterstic!)
//                            return
//                        }
//                    }
//                }
//
//            }
//        }
//        self.centralManager.cancelPeripheralConnection(self.peripheralNew)
//    }
//
//    //**************************************************
//
//************************************************
//
//    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
//        if((error) != nil)
//        {
//            print("Error Discovering Services \([error?.localizedDescription])")
//            self.clean()
//            return
//        }
//        for service:CBService in peripheral.services!
//        {
//            if let characterstic = service.characteristics?.first(where:{ $0.uuid == BLEService_UUID})
//            {
//                peripheral.discoverCharacteristics([BLE_Characteristic_uuid_Tx], for: service)
//
//            }
//        }
//
//    }
//    //**************************************************
//
//    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
//        if(error != nil)
//        {
//            print("Error discovering characterstics \([error?.localizedDescription])")
//            self.clean()
//            return
//        }
//
//        for characteristic:CBCharacteristic in service.characteristics!
//        {
//            if((characteristic.uuid.isEqual([BLE_Characteristic_uuid_Tx])))
//         {
//                peripheral.setNotifyValue(true, for: characteristic)
//            peripheral.readValue(for: characteristic)
//            }
//            if (service.characteristics?.first(where : { $0.uuid == BLE_Characteristic_uuid_Tx})) != nil {
//                peripheral.discoverDescriptors(for: characteristic)
//
//            }
//
//
//        }
//    }
//    //**************************************************
//
//
//    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
//        if(error != nil)
//        {
//            print("Error discovering characteristics \([error?.localizedDescription])")
//            return
//        }
//        let stringFromData:String = NSString.init(data: characteristic.value!, encoding: String.Encoding.utf8.rawValue)! as String
//        if(stringFromData == "EOM")
//        {
//            self.centralTextView.text = NSString.init(data: self.data as Data, encoding: String.Encoding.utf8.rawValue) as String?
//            peripheral.setNotifyValue(false, for: characteristic)
//            self.centralManager.cancelPeripheralConnection(peripheral)
//        }
//        self.data.append(characteristic.value!)
//        print("Recieved \(stringFromData)")
//
//    }
//    //**************************************************
//
//
//    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
//        if(error != nil)
//        {
//            print("Error changing notification state \([error?.localizedDescription])")
//            return
//        }
//        if((characteristic.uuid.isEqual([CBUUID.init(string: "08590F7E-DB05-467E-8757-72F6FAEB13D4")])))
//        {
//            return
//        }
//        if(characteristic.isNotifying)
//        {
//            print("Notification Begin \(characteristic)")
//        }
//        else
//        {
//            print("Notification Stopped \(characteristic) disconnecting")
//            self.centralManager.cancelPeripheralConnection(peripheral)
//
//        }
//    }
//
//
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("Peripheral disconected")
        self.peripheralNew = nil
        self.scan()
    }

}

